#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>

#define CLA_DUP 0
#define SIN_MEM 0
#define SIN_INICIALIZAR 0
#define ERROR_ARCH 0
#define TODO_BIEN 1

typedef struct sNodoArbol
{
    void *info;
    unsigned tamInfo;
    struct sNodoArbol *izq,
                      *der;
} tNodoArbol;

typedef tNodoArbol *tArbolBinBusq;

void crearArbolBinBusq(tArbolBinBusq *p);

int insertarArbolBinBusq(tArbolBinBusq *p, const void *d, unsigned tam,
                         int (*cmp)(const void *, const void *));
int insertarRecArbolBinBusq(tArbolBinBusq *p, const void *d, unsigned tam,
                            int (*cmp)(const void*, const void *));

void recorrerEnOrdenArbolBinBusq(const tArbolBinBusq *p, void *params,
                                 void (*accion)(void *, unsigned, unsigned, void *));
void recorrerEnOrdenInversoArbolBinBusq(const tArbolBinBusq *p, void *params,
                                        void (*accion)(void *, unsigned, unsigned, void *));
void recorrerPreOrdenArbolBinBusq(const tArbolBinBusq *p, void *params,
                                  void (*accion)(void *, unsigned, unsigned, void *));
void recorrerPosOrdenArbolBinBusq(const tArbolBinBusq *p, void *params,
                                  void (*accion)(void *, unsigned, unsigned, void *));

void recorrerEnOrdenSimpleArbolBinBusq(const tArbolBinBusq *p, void *params,
                                      void (*accion)(void *, unsigned, void *));
void recorrerPreOrdenSimpleArbolBinBusq(const tArbolBinBusq *p, void *params,
                                        void (*accion)(void *, unsigned, void *));
void recorrerPosOrdenSimpleArbolBinBusq(const tArbolBinBusq *p, void *params,
                                        void (*accion)(void *, unsigned, void *));

int eliminarRaizArbolBinBusq(tArbolBinBusq *p);
int eliminarElemArbolBinBusq(tArbolBinBusq *p, void *d, unsigned tam,
                             int (*cmp)(const void *, const void *));
int buscarElemArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam,
                           int (*cmp)(const void *, const void *));

int cargarArchivoBinOrdenadoAbiertoArbolBinBusq(tArbolBinBusq *p, FILE *pf,
                                               unsigned tamInfo);
int cargarArchivoBinOrdenadoArbolBinBusq(tArbolBinBusq *p, const char *path,
                                         unsigned tamInfo);
int cargarDesdeDatosOrdenadosArbolBinBusq(tArbolBinBusq *p,
                                          void *ds, unsigned cantReg,
                                          unsigned (*leer)(void **, void *, unsigned, void *params),
                                          void *params);

int mayorElemNoClaveArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam,
                                 int (*cmp)(const void *, const void *));
int menorElemNoClaveArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam,
                                 int (*cmp)(const void *, const void *));
int buscarElemNoClaveArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam,
                                  int (*cmp)(const void *, const void *));
unsigned alturaArbolBin(const tArbolBinBusq *p);
unsigned cantNodosArbolBin(const tArbolBinBusq *p);
unsigned cantNodosHastaNivelArbolBin(const tArbolBinBusq *p, int n);
int mayorElemArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam);
int menorElemArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam);
int esCompletoArbolBin(const tArbolBinBusq *p);
int esBalanceadoArbolBin(const tArbolBinBusq *p);
int esAVLArbolBin(const tArbolBinBusq *p);
int esCompleto2ArbolBin(const tArbolBinBusq *p);
int esBalanceado2ArbolBin(const tArbolBinBusq *p);
int esAVL2ArbolBin(const tArbolBinBusq *p);
---------------------------------------------------


#define MINIMO(X,Y) ((X)<(Y)?(X):(Y))

tNodoArbol **mayorNodoArbolBusq(const tArbolBinBusq *p)
{
    if(!*p)
        return NULL;
    if(!(*p)->der)
        return (tNodoArbol**)p;
    return mayorNodoArbolBusq(&(*p)->der);
}

tNodoArbol **menorNodoArbolBusq(const tArbolBinBusq *p)
{
    if(!*p)
        return NULL;
    if(!(*p)->izq)
        return (tNodoArbol**)p;
    return menorNodoArbolBusq(&(*p)->izq);
}

void crearArbolBinBusq(tArbolBinBusq *p)
{
    *p = NULL;
}

int insertarArbolBinBusq(tArbolBinBusq *p, const void *d, unsigned tam,
                         int (*cmp)(const void *, const void *))
{
    if(!*p)
        return insertarRecArbolBinBusq(p, d, tam, cmp);
    return insertarRecArbolBinBusq(&(*p)->der, d, tam, cmp) ||
           insertarRecArbolBinBusq(&(*p)->izq, d, tam, cmp);
}

int insertarRecArbolBinBusq(tArbolBinBusq *p, const void *d, unsigned tam,
                            int (*cmp)(const void*, const void *))
{
    int c;
    void *info;
    if(!*p)
    {
        info = malloc(tam);
        if(!info)
            return SIN_MEM;
        memcpy(info, d, tam);
        *p = malloc(sizeof(tNodoArbol));
        if(!*p)
        {
            free(info);
            return SIN_MEM;
        }
        (*p)->info = info;
        (*p)->tamInfo = tam;
        (*p)->izq = (*p)->der = NULL;
        return TODO_BIEN;
    }
    c = cmp(d, (*p)->info);
    if(!c)
        return CLA_DUP;
    return insertarRecArbolBinBusq(c < 0 ? &(*p)->izq : &(*p)->der, d, tam, cmp);
}

void recorrerEnOrdenArbolBinBusq(const tArbolBinBusq *p, void *params,
                                 void (*accion)(void *, unsigned, unsigned, void *))
{
    if(*p)
    {
        recorrerEnOrdenArbolBinBusq(&(*p)->izq, params, accion);
        accion((*p)->info, (*p)->tamInfo, 0, params);
        recorrerEnOrdenArbolBinBusq(&(*p)->der, params, accion);
    }
}

void recorrerEnOrdenInversoArbolBinBusq(const tArbolBinBusq *p, void *params,
                                        void (*accion)(void *, unsigned, unsigned, void *))
{
    if(*p)
    {
        recorrerEnOrdenInversoArbolBinBusq(&(*p)->der, params, accion);
        accion((*p)->info, (*p)->tamInfo, 0, params);
        recorrerEnOrdenInversoArbolBinBusq(&(*p)->izq, params, accion);
    }
}

void recorrerPreOrdenArbolBinBusq(const tArbolBinBusq *p, void *params,
                                  void (*accion)(void *, unsigned, unsigned, void *))
{
    if(*p)
    {
        accion((*p)->info, (*p)->tamInfo, 0, params);
        recorrerPreOrdenArbolBinBusq(&(*p)->izq, params, accion);
        recorrerPreOrdenArbolBinBusq(&(*p)->der, params, accion);
    }
}

void recorrerPosOrdenArbolBinBusq(const tArbolBinBusq *p, void *params,
                                  void (*accion)(void *, unsigned, unsigned, void *))
{
    if(*p)
    {
        recorrerPosOrdenArbolBinBusq(&(*p)->izq, params, accion);
        recorrerPosOrdenArbolBinBusq(&(*p)->der, params, accion);
        accion((*p)->info, (*p)->tamInfo, 0, params);
    }
}

void recorrerEnOrdenSimpleArbolBinBusq(const tArbolBinBusq *p, void *params,
                                      void (*accion)(void *, unsigned, void *))
{
    if(*p)
    {
        recorrerEnOrdenSimpleArbolBinBusq(&(*p)->izq, params, accion);
        accion((*p)->info, (*p)->tamInfo, params);
        recorrerEnOrdenSimpleArbolBinBusq(&(*p)->der, params, accion);
    }
}

void recorrerPreOrdenSimpleArbolBinBusq(const tArbolBinBusq *p, void *params,
                                        void (*accion)(void *, unsigned, void *))
{
    if(*p)
    {
        accion((*p)->info, (*p)->tamInfo, params);
        recorrerPreOrdenSimpleArbolBinBusq(&(*p)->izq, params, accion);
        recorrerPreOrdenSimpleArbolBusq(&(*p)->der, params, accion);
    }
}

void recorrerPosOrdenSimpleArbolBinBusq(const tArbolBinBusq *p, void *params,
                                        void (*accion)(void *, unsigned, void *))
{
    if(*p)
    {
        recorrerPosOrdenSimpleArbolBinBusq(&(*p)->izq, params, accion);
        recorrerPosOrdenSimpleArbolBusq(&(*p)->der, params, accion);
        accion((*p)->info, (*p)->tamInfo, params);
    }
}

int eliminarRaizArbolBinBusq(tArbolBinBusq *p)
{
    void *auxInfo;
    unsigned auxTam;
    tNodoArbol **nodo;

    if(!*p)
        return SIN_INICIALIZAR;
    if(!(*p)->izq && !(*p)->der)
    {
        free((*p)->info);
        free(*p);
        *p = NULL;
        return TODO_BIEN;
    }
    nodo = (*p)->izq ? mayorNodoArbolBusq(&(*p)->izq)
                     : menorNodoArbolBusq(&(*p)->der);

    auxInfo = (*nodo)->info;
    auxTam  = (*nodo)->tamInfo;
    (*nodo)->info = (*p)->info;
    (*nodo)->tamInfo = (*p)->tamInfo;
    (*p)->info = auxInfo;
    (*p)->tamInfo = auxTam;

    return eliminarRaizArbolBinBusq(&(*p)->izq);
}

int eliminarElemArbolBinBusq(tArbolBinBusq *p, void *d, unsigned tam,
                             int (*cmp)(const void *, const void *))
{
    if(!*p)
        return SIN_INICIALIZAR;
    if(cmp(d, (*p)->info) < 0)
        return eliminarElemArbolBinBusq(&(*p)->izq, d, tam, cmp);
    if(cmp(d, (*p)->info) > 0)
        return eliminarElemArbolBinBusq(&(*p)->der, d, tam, cmp);
    return eliminarRaizArbolBinBusq(p);
}

int buscarElemArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam,
                           int (*cmp)(const void *, const void *))
{
    int c;
    if(!*p)
        return SIN_INICIALIZAR;
    c = cmp(d, (*p)->info);
    if(!c)
    {
        memcpy(d, (*p)->info, MINIMO(tam, (*p)->tamInfo));
        return TODO_BIEN;
    }
    return buscarElemArbolBinBusq(c < 0 ? &(*p)->izq : &(*p)->der, d, tam, cmp);
}

int cargarArchivoBinOrdenadoAbiertoArbolBinBusq(tArbolBinBusq *p, FILE *pf,
                                               unsigned tamInfo)
{
    int cantReg;
    if(*p || !pf)
        return ERROR_ARCH;
    fseek(pf, 0L, SEEK_END);
    cantReg = ftell(pf)/tamInfo;
    fseek(pf, 0L, SEEK_SET);
    return cargarDesdeDatosOrdenadosRec(p, pf, leerDesdeArchivoBin, 0, cantReg-1, &tamInfo);
}

int cargarArchivoBinOrdenadoArbolBinBusq(tArbolBinBusq *p, const char *path,
                                         unsigned tamInfo)
{
    FILE *pf = fopen(path, "rb");
    if(!pf)
        return ERROR_ARCH;
    int res = cargarArchivoBinOrdenadoAbiertoArbolBinBusq(p, pf, tamInfo);
    fclose(pf);
    return res;
}

unsigned leerDesdeArchivoBin(void **d, void *vec, unsigned pos, void *params)
{
    unsigned tam = *((unsigned*)params);
    *d = malloc(tam);
    if(!*d)
        return 0;
    fseek((FILE*)vec, pos*tam, SEEK_SET);
    return fread(*d, tam, 1, (FILE*)vec);
}

int cargarDesdeDatosOrdenadosArbolBinBusq(tArbolBinBusq *p,
                                          void *ds, unsigned cantReg,
                                          unsigned (*leer)(void **, void *, unsigned, void *),
                                          void *params)
{
    if(!cantReg)
        return SIN_INICIALIZAR;
    return cargarDesdeDatosOrdenadosRec(p, ds, leer, 0, cantReg-1, params);
}

int cargarDesdeDatosOrdenadosRec(tArbolBinBusq *p, void *ds,
                                 unsigned (*leer)(void **, void *, unsigned, void *),
                                 int li, int ls, void *params)
{
    int m = (li+ls)/2,
        r;
    void *dAux;

    if(li > ls)
        return TODO_BIEN;
    r = (*leer)(&dAux, ds, m, params);
    if(!r)
        return SIN_MEM;
    insertarArbolBinBusq(p, dAux, r, cmp_ent);
    free(dAux);

    if(li < m)
        cargarDesdeDatosOrdenadosRec(&(*p)->izq, ds, leer, li, m-1, params);
    if(m < ls)
        cargarDesdeDatosOrdenadosRec(&(*p)->der, ds, leer, m+1, ls, params);

    return TODO_BIEN;
}

int mayorElemNoClaveArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam,
                                 int (*cmp)(const void *, const void *))
{
    tNodoArbol **nodo = mayorNodoArbolBusq(p);
    if(!nodo)
        return SIN_INICIALIZAR;
    memcpy(d, (*nodo)->info, MINIMO(tam, (*nodo)->tamInfo));
    return TODO_BIEN;
}

int menorElemNoClaveArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam,
                                 int (*cmp)(const void *, const void *))
{
    tNodoArbol **nodo = menorNodoArbolBusq(p);
    if(!nodo)
        return SIN_INICIALIZAR;
    memcpy(d, (*nodo)->info, MINIMO(tam, (*nodo)->tamInfo));
    return TODO_BIEN;
}

int buscarElemNoClaveArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam,
                                  int (*cmp)(const void *, const void *))
{
    tNodoArbol *aux;
    if(!*p)
        return SIN_INICIALIZAR;
    if(cmp(d, (*p)->info) < 0)
        return buscarElemNoClaveArbolBinBusq(&(*p)->izq, d, tam, cmp);
    if(cmp(d, (*p)->info) > 0)
        return buscarElemNoClaveArbolBinBusq(&(*p)->der, d, tam, cmp);
    aux = *p;
    memcpy(d, aux->info, MINIMO(tam, aux->tamInfo));
    return TODO_BIEN;
}

// ** Funciones de Utilidad **

unsigned alturaArbolBin(const tArbolBinBusq *p)
{
    if(!*p) return 0;
    unsigned hIz = alturaArbolBin(&(*p)->izq),
             hDer = alturaArbolBin(&(*p)->der);
    return 1 + (hIz > hDer ? hIz : hDer);
}

unsigned cantNodosArbolBin(const tArbolBinBusq *p)
{
    if(!*p) return 0;
    return 1 + cantNodosArbolBin(&(*p)->izq)
             + cantNodosArbolBin(&(*p)->der);
}

unsigned cantNodosHastaNivelArbolBin(const tArbolBinBusq *p, int n)
{
    if(!*p || n < 0) return 0;
    if(!n) return 1;
    return cantNodosHastaNivelArbolBin(&(*p)->izq, n-1)
         + cantNodosHastaNivelArbolBin(&(*p)->der, n-1);
}

int mayorElemArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam)
{
    return mayorElemNoClaveArbolBinBusq(p, d, tam, cmp_ent);
}

int menorElemArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam)
{
    return menorElemNoClaveArbolBinBusq(p, d, tam, cmp_ent);
}

int esCompletoArbolBin(const tArbolBinBusq *p)
{
    unsigned h = alturaArbolBin(p);
    unsigned nodos = cantNodosArbolBin(p);
    return nodos == ((1u << h) - 1);
}

int esBalanceadoArbolBin(const tArbolBinBusq *p)
{
    if(!*p) return 1;
    int balIz = esBalanceadoArbolBin(&(*p)->izq),
        balDer = esBalanceadoArbolBin(&(*p)->der);
    return balIz && balDer &&
           abs((int)alturaArbolBin(&(*p)->izq) - (int)alturaArbolBin(&(*p)->der)) <= 1;
}

int esAVLArbolBin(const tArbolBinBusq *p)
{
    return esCompletoArbolBin(p) && esBalanceadoArbolBin(p);
}

int esCompleto2ArbolBin(const tArbolBinBusq *p)
{
    if(!*p) return 1;
    unsigned h = alturaArbolBin(p) - 1;
    return cantNodosHastaNivelArbolBin(p, h - 1) == ((1u << h) - 1)
        && esCompleto2ArbolBin(&(*p)->izq)
        && esCompleto2ArbolBin(&(*p)->der);
}

int esBalanceado2ArbolBin(const tArbolBinBusq *p)
{
    if(!*p) return 1;
    int balIz = esBalanceado2ArbolBin(&(*p)->izq),
        balDer = esBalanceado2ArbolBin(&(*p)->der);
    return balIz && balDer &&
           abs((int)cantNodosArbolBin(&(*p)->izq) - (int)cantNodosArbolBin(&(*p)->der)) <= 1;
}

int esAVL2ArbolBin(const tArbolBinBusq *p)
{
    return esCompleto2ArbolBin(p) && esBalanceado2ArbolBin(p);
}



