
typedef struct sNodo
{
    void           *info;
    unsigned        tamInfo;
    struct sNodo   *sig;
} tNodo;
typedef tNodo *tLista;

void crearLista(tLista *p);

int  listaVacia(const tLista *p);

int  listaLlena(const tLista *p, unsigned cantBytes);

int  vaciarLista(tLista *p);

int  vaciarListaYMostrar(tLista *p,
                         void (*mostrar)(const void *, FILE *), FILE *fp);

int  ponerAlComienzo(tLista *p, const void *d, unsigned cantBytes);

int  sacarPrimeroLista(tLista *p, void *d, unsigned cantBytes);

int  verPrimeroLista(const tLista *p, void *d, unsigned cantBytes);

int  ponerAlFinal(tLista *p, const void *d, unsigned cantBytes);

int  sacarUltimoLista(tLista *p, void *d, unsigned cantBytes);

int  verUltimoLista(const tLista *p, void *d, unsigned cantBytes);

int  mostrarLista(const tLista *p,
                  void (*mostrar)(const void *, FILE *), FILE *fp);

int  mostrarListaAlReves(const tLista *p,
                         void (*mostrar)(const void *, FILE *), FILE *fp);

int  mostrarListaAlRevesYVaciar(tLista *p,
                                void (*mostrar)(const void *, FILE *),
                                FILE *fp);

int  ponerEnOrden(tLista *p, const void *d, unsigned cantBytes,
                  int (*comparar)(const void *, const void *),
                  int (*acumular)(void **, unsigned *, const void *, unsigned));

void ordenar(tLista *p, int (*comparar)(const void *, const void *));
-----------------------------------------

#define minimo( X , Y )     ( ( X ) <= ( Y ) ? ( X ) : ( Y ) )

void crearLista(tLista *p)
{
    *p = NULL;
}

int  listaVacia(const tLista *p)
{
    return *p == NULL;
}

int  listaLlena(const tLista *p, unsigned cantBytes)
{
    tNodo  *aux = (tNodo *)malloc(sizeof(tNodo));
    void   *info = malloc(cantBytes);

    free(aux);
    free(info);
    return aux == NULL || info == NULL;
}

int vaciarLista(tLista *p)
{
    int cant = 0;
    while(*p)
    {
        tNodo *aux = *p;

        cant++;
        *p = aux->sig;
        free(aux->info);
        free(aux);
    }
    return cant;
}

int  vaciarListaYMostrar(tLista *p,
                         void (*mostrar)(const void *, FILE *), FILE *fp)
{
    int cant = 0;
    while(*p)
    {
        tNodo *aux = *p;

        cant++;
        *p = aux->sig;
        if(mostrar && fp)
            mostrar(aux->info, fp);
        free(aux->info);
        free(aux);
    }
    return cant;
}

int  ponerAlComienzo(tLista *p, const void *d, unsigned cantBytes)
{
    tNodo *nue;

    if((nue = (tNodo *)malloc(sizeof(tNodo))) == NULL ||
       (nue->info = malloc(cantBytes)) == NULL)
    {
        free(nue);
        return 0;
    }
    memcpy(nue->info, d, cantBytes);
    nue->tamInfo = cantBytes;
    nue->sig = *p;
    *p = nue;
    return 1;
}

int  sacarPrimeroLista(tLista *p, void *d, unsigned cantBytes)
{
    tNodo *aux = *p;

    if(aux == NULL)
        return 0;
    *p = aux->sig;
    memcpy(d, aux->info, minimo(cantBytes, aux->tamInfo));
    free(aux->info);
    free(aux);
    return 1;
}

int  verPrimeroLista(const tLista *p, void *d, unsigned cantBytes)
{
    if(*p == NULL)
        return 0;
    memcpy(d, (*p)->info, minimo(cantBytes, (*p)->tamInfo));
    return 1;
}

int  ponerAlFinal(tLista *p, const void *d, unsigned cantBytes)
{
    tNodo  *nue;

    while(*p)
        p = &(*p)->sig;
    if((nue = (tNodo *)malloc(sizeof(tNodo))) == NULL ||
       (nue->info = malloc(cantBytes)) == NULL)
    {
        free(nue);
        return 0;
    }
    memcpy(nue->info, d, cantBytes);
    nue->tamInfo = cantBytes;
    nue->sig = NULL;
    *p = nue;
    return 1;
}

int  sacarUltimoLista(tLista *p, void *d, unsigned cantBytes)
{
    if(*p == NULL)
        return 0;
    while((*p)->sig)
        p = &(*p)->sig;
    memcpy(d, (*p)->info, minimo(cantBytes, (*p)->tamInfo));
    free((*p)->info);
    free(*p);
    *p = NULL;
    return 1;
}

int  verUltimoLista(const tLista *p, void *d, unsigned cantBytes)
{
    if(*p == NULL)
        return 0;
    while((*p)->sig)
        p = &(*p)->sig;
    memcpy(d, (*p)->info, minimo(cantBytes, (*p)->tamInfo));
    return 1;
}

int  mostrarLista(const tLista *p,
                  void (*mostrar)(const void *, FILE *), FILE *fp)
{
    int     cant = 0;

    while(*p)
    {
        mostrar((*p)->info, fp);
        p = &(*p)->sig;
        cant++;
    }
    return cant;
}

int  mostrarListaAlReves(const tLista *p,
                         void (*mostrar)(const void *, FILE *), FILE *fp)
{
    if(*p)
    {
        int n = mostrarListaAlReves(&(*p)->sig, mostrar, fp);

        mostrar((*p)->info, fp);
        return n + 1;
    }
    return 0;
}

int  mostrarListaAlRevesYVaciar(tLista *p,
                                void (*mostrar)(const void *, FILE *),
                                FILE *fp)
{
    if(*p)
    {
        int n = mostrarListaAlReves(&(*p)->sig, mostrar, fp);

        mostrar((*p)->info, fp);
        free((*p)->info);
        free(*p);
        *p = NULL;
        return n + 1;
    }
    return 0;
}

int  ponerEnOrden(tLista *p, const void *d, unsigned cantBytes,
                  int (*comparar)(const void *, const void *),
                  int (*acumular)(void **, unsigned *, const void *, unsigned))
{
    tNodo  *nue;

    while(*p && comparar((*p)->info, d) < 0)
        p = &(*p)->sig;
    if(*p && comparar((*p)->info, d) == 0)
    {
        if(acumular)
            if(!acumular(&(*p)->info, &(*p)->tamInfo, d, cantBytes))
               return SIN_MEM;
        return CLA_DUP;
    }
    if((nue = (tNodo  *)malloc(sizeof(tNodo))) == NULL ||
       (nue->info = malloc(cantBytes)) == NULL)
    {
        free(nue);
        return SIN_MEM;
    }
    memcpy(nue->info, d, cantBytes);
    nue->tamInfo = cantBytes;
    nue->sig = *p;
    *p = nue;
    return TODO_BIEN;
}

void ordenar(tLista *p, int (*comparar)(const void *, const void *))
{
    tLista     *pri = p;

    if(*p == NULL)
        return;
    while((*p)->sig)
    {
        if(comparar((*p)->info, (*p)->sig->info) > 0)
        {
            tLista *q = pri;
            tNodo *aux = (*p)->sig;

            (*p)->sig = aux->sig;
            while(comparar((*q)->info, aux->info) > 0)
                q = &(*q)->sig;
            aux->sig = *q;
            *q = aux;
        }
        else
            p = &(*p)->sig;
    }
}
